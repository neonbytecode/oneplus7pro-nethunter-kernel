#!/system/bin/sh
# Load the NetHunter addon kernel modules at post-fs-data.
#
# Load dependency modules first.  Most kernel subsystems are built in, but
# option needs usb_wwan and squashfs needs zstd_decompress, which needs xxhash.
#
# This script must never block boot: every failure is logged and ignored.

MODDIR=${0%/*}
LOG=/data/adb/nh-kernel-addons.log
BB=/data/adb/magisk/busybox
[ -x "$BB" ] || BB=""

log() { echo "$(date '+%Y-%m-%d %T') $*" >> "$LOG"; }

# keep the log from growing forever across many boots
if [ -f "$LOG" ] && [ "$(wc -c < "$LOG" 2>/dev/null || echo 0)" -gt 65536 ]; then
    : > "$LOG"
fi
log "--- boot-safe mode: automatic module loading disabled"
log "--- use: su -c sh $MODDIR/load-on-demand.sh MODULE [MODULE ...]"
