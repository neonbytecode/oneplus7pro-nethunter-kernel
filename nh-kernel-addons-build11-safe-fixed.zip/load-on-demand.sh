#!/system/bin/sh
# Load explicitly requested modules only. Nothing calls this script at boot.
set -u

MODDIR=${0%/*}
LOG=/data/adb/nh-kernel-addons.log
BB=/data/adb/magisk/busybox
[ -x "$BB" ] || BB=""

log() { echo "$(date '+%Y-%m-%d %T') $*" >> "$LOG"; }

load_one() {
    module_name=$1
    grep -q "^$module_name " /proc/modules 2>/dev/null && { log "$module_name: already loaded"; return 0; }
    ko="$MODDIR/modules/$module_name.ko"
    [ -f "$ko" ] || { log "$module_name: missing"; return 1; }
    if [ -n "$BB" ]; then
        "$BB" insmod "$ko" 2>>"$LOG"
    else
        insmod "$ko" 2>>"$LOG"
    fi
    rc=$?
    [ "$rc" -eq 0 ] && log "$module_name: loaded on demand" || log "$module_name: FAILED on demand ($rc)"
    return "$rc"
}

[ "$#" -gt 0 ] || { echo "usage: $0 MODULE [MODULE ...]" >&2; exit 2; }
for requested in "$@"; do
    case "$requested" in
        squashfs) load_one xxhash && load_one zstd_decompress || exit $? ;;
        option) load_one usb_wwan || exit $? ;;
    esac
    load_one "$requested" || exit $?
done
